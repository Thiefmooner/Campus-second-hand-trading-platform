package com.wfuhui.modules.chat.api;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wfuhui.common.utils.R;
import com.wfuhui.modules.chat.entity.ChatEntity;
import com.wfuhui.modules.chat.service.ChatService;
import com.wfuhui.modules.member.service.MemberService;

/**
 * 消息
 */
@RestController
@RequestMapping("/api/chat/")
public class ApiChatController {
	
	@Autowired
	private ChatService chatService;
	@Autowired
	private MemberService userService;
	
    @GetMapping("list")
    public R list(Integer adminId, @RequestAttribute("userId") Long userId, String type){
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("userId", userId);
		map.put("adminId", adminId);
		List<ChatEntity> chatList = chatService.queryListByUser(map);
    	return R.ok().put("chatList", chatList);
    }
    
	
    @GetMapping("detail")
    public R detail(Integer adminId, @RequestAttribute("userId") Long userId, String type, String sessionId){
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("sessionId", sessionId);
		List<ChatEntity> chatList = chatService.queryDetailByUser(map);
    	return R.ok().put("chatList", chatList);
    }
    
    @PostMapping("add")
    public R add(@RequestBody ChatEntity chat, @RequestAttribute("userId") Long userId, String type){
		chat.setUserId(userId);
    	chat.setCreateTime(new Date());
    	chat.setType(2);
    	if("admin".equals(type)) {
        	chat.setType(1);
        	chat.setAdminId(userId);
    	}
    	chat.setRead(0);
    	chatService.save(chat);
    	return R.ok().put("chat", chat);
    }
    
}
