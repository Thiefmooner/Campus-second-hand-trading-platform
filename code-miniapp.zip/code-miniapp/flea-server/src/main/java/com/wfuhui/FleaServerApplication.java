package com.wfuhui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 启动类 *
 */
@SpringBootApplication
public class FleaServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(FleaServerApplication.class, args);
    }

}
