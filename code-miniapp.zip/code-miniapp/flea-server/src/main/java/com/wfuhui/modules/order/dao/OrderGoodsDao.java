package com.wfuhui.modules.order.dao;

import org.apache.ibatis.annotations.Mapper;

import com.wfuhui.modules.order.entity.OrderGoodsEntity;
import com.wfuhui.modules.sys.dao.BaseDao;


@Mapper
public interface OrderGoodsDao extends BaseDao<OrderGoodsEntity> {
	
}
