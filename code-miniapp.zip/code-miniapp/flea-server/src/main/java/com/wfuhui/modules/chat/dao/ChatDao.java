package com.wfuhui.modules.chat.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.wfuhui.modules.chat.entity.ChatEntity;
import com.wfuhui.modules.sys.dao.BaseDao;

/**
 * 留言
 */
@Mapper
public interface ChatDao extends BaseDao<ChatEntity> {

	List<ChatEntity> queryListByUser(Map<String, Object> map);

	List<ChatEntity> queryDetailByUser(Map<String, Object> map);

	void updateByJobId(Integer noticeId);

	Integer queryUnread(Long userId);

	List<ChatEntity> queryListByAdmin(Map<String, Object> map);
	
}
