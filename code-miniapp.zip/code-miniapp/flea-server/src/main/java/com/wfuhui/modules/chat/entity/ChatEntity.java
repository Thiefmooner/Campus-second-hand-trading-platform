package com.wfuhui.modules.chat.entity;

import java.io.Serializable;
import java.util.Date;

import com.wfuhui.modules.member.entity.MemberEntity;

/**
 * 留言
 */
public class ChatEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	// 主键
	private Integer id;
	// 发送者
	private Long userId;
	// 接收者
	private Long adminId;
	// 内容
	private String content;
	// 创建时间
	private Date createTime;
	// 是否已读，1已读，0未读
	private Integer read;

	private MemberEntity user;

	private Integer messageCount;

	private Integer type;

	private Integer msgType;
	
	private String sessionId;
	
	

	/**
	 * 设置：主键
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * 获取：主键
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * 设置：内容
	 */
	public void setContent(String content) {
		this.content = content;
	}

	/**
	 * 获取：内容
	 */
	public String getContent() {
		return content;
	}

	/**
	 * 设置：创建时间
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	/**
	 * 获取：创建时间
	 */
	public Date getCreateTime() {
		return createTime;
	}

	/**
	 * 设置：是否已读，1已读，0未读
	 */
	public void setRead(Integer read) {
		this.read = read;
	}

	/**
	 * 获取：是否已读，1已读，0未读
	 */
	public Integer getRead() {
		return read;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getAdminId() {
		return adminId;
	}

	public void setAdminId(Long adminId) {
		this.adminId = adminId;
	}

	public Integer getMessageCount() {
		return messageCount;
	}

	public void setMessageCount(Integer messageCount) {
		this.messageCount = messageCount;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getMsgType() {
		return msgType;
	}

	public void setMsgType(Integer msgType) {
		this.msgType = msgType;
	}

	public MemberEntity getUser() {
		return user;
	}

	public void setUser(MemberEntity user) {
		this.user = user;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	
}
