package com.wfuhui.modules.chat.service;

import java.util.List;
import java.util.Map;

import com.wfuhui.modules.chat.entity.ChatEntity;

/**
 * 留言
 *
 */
public interface ChatService {
	
	ChatEntity queryObject(Integer id);
	
	List<ChatEntity> queryList(Map<String, Object> map);
	
	int queryTotal(Map<String, Object> map);
	
	void save(ChatEntity chat);
	
	void update(ChatEntity chat);
	
	void delete(Integer id);
	
	void deleteBatch(Integer[] ids);

	List<ChatEntity> queryListByUser(Map<String, Object> map);

	List<ChatEntity> queryDetailByUser(Map<String, Object> map);

	void updateByJobId(Integer noticeId);

	Integer queryUnread(Long userId);

	List<ChatEntity> queryListByAdmin(Map<String, Object> map);
}
