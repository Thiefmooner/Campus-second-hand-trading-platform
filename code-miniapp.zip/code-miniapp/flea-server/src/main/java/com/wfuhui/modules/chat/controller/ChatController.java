package com.wfuhui.modules.chat.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wfuhui.common.utils.Query;
import com.wfuhui.common.utils.R;
import com.wfuhui.modules.chat.entity.ChatEntity;
import com.wfuhui.modules.chat.service.ChatService;

/**
 * 留言
 */
@RestController
@RequestMapping("chat")
public class ChatController {
	@Autowired
	private ChatService chatService;
	
	
	@RequestMapping("/unread")
	@RequiresPermissions("chat:list")
	public R unread(){
		Integer total = chatService.queryUnread(1l);
		return R.ok().put("total", total);
	}
	
	@RequestMapping("/updateByJobId")
	@RequiresPermissions("chat:update")
	public R updateByJobId(Integer jobId){
		
		chatService.updateByJobId(jobId);
		return R.ok();
	}
	
	/**
	 * 列表
	 */
	@RequestMapping("/list")
	@RequiresPermissions("chat:list")
	public R list(@RequestParam Map<String, Object> params){
		//查询列表数据
        Query query = new Query(params);

		List<ChatEntity> chatList = chatService.queryList(query);
		int total = chatService.queryTotal(query);
		
		return R.ok().put("rows", chatList).put("total", total);
	}
	
	
	/**
	 * 信息
	 */
	@RequestMapping("/info/{id}")
	@RequiresPermissions("chat:info")
	public R info(@PathVariable("id") Integer id){
		ChatEntity chat = chatService.queryObject(id);
		
		return R.ok().put("chat", chat);
	}
	
	@RequestMapping("/infoByCvId")
	@RequiresPermissions("chat:info")
	public R infoByJobId(Integer cvId){
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("cvId", cvId);
		List<ChatEntity> chatList = chatService.queryDetailByUser(map);
		return R.ok().put("chatList", chatList);
	}
	
	/**
	 * 保存
	 */
	@RequestMapping("/save")
	@RequiresPermissions("chat:save")
	public R save(@RequestBody ChatEntity chat){
		chat.setCreateTime(new Date());
		chat.setType(1);
		chat.setRead(0);
		chatService.save(chat);
		return R.ok().put("chat", chat);
	}
	
	/**
	 * 修改
	 */
	@RequestMapping("/update")
	@RequiresPermissions("chat:update")
	public R update(@RequestBody ChatEntity chat){
		chatService.update(chat);
		
		return R.ok();
	}
	
	/**
	 * 删除
	 */
	@RequestMapping("/delete")
	@RequiresPermissions("chat:delete")
	public R delete(@RequestBody Integer[] ids){
		chatService.deleteBatch(ids);
		
		return R.ok();
	}
	
}
