/*
 Navicat MySQL Data Transfer

 Source Server         : cyh
 Source Server Type    : MySQL
 Source Server Version : 80018
 Source Host           : rm-2zebswk9i942l1ycq2o.mysql.rds.aliyuncs.com:3306
 Source Schema         : cyh

 Target Server Type    : MySQL
 Target Server Version : 80018
 File Encoding         : 65001

 Date: 27/05/2021 15:33:19
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for chat_message
-- ----------------------------
DROP TABLE IF EXISTS `chat_message`;
CREATE TABLE `chat_message`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NULL DEFAULT NULL,
  `admin_id` int(11) NULL DEFAULT NULL,
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '内容',
  `read` tinyint(2) NULL DEFAULT NULL,
  `type` tinyint(2) NULL DEFAULT NULL,
  `msg_type` tinyint(2) NULL DEFAULT NULL,
  `session_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 39 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '聊天' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of chat_message
-- ----------------------------
INSERT INTO `chat_message` VALUES (38, 66, 66, '你好', 0, 2, 1, '1616770940684', '2021-03-26 23:02:27');

-- ----------------------------
-- Table structure for flea_advert
-- ----------------------------
DROP TABLE IF EXISTS `flea_advert`;
CREATE TABLE `flea_advert`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pic_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图片地址',
  `enable` tinyint(4) NULL DEFAULT NULL COMMENT '是否启用，0：禁用，1：启用',
  `link` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '链接',
  `sort` int(11) NULL DEFAULT NULL COMMENT '排序',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '广告' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of flea_advert
-- ----------------------------
INSERT INTO `flea_advert` VALUES (1, 'http://localhost:10001/img/banner-1.jpg', 1, NULL, 1, '2021-04-06 13:44:57');
INSERT INTO `flea_advert` VALUES (2, 'http://localhost:10001/img/banner-2.jpg', 1, NULL, 2, '2021-04-07 13:45:13');

-- ----------------------------
-- Table structure for flea_category
-- ----------------------------
DROP TABLE IF EXISTS `flea_category`;
CREATE TABLE `flea_category`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '分类名称',
  `pic_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图片',
  `sort` int(11) NULL DEFAULT NULL COMMENT '排序',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '分类' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of flea_category
-- ----------------------------
INSERT INTO `flea_category` VALUES (1, '图书', 'http://localhost:10001/img/icon-1.png', 1, '2021-04-06 19:33:12');
INSERT INTO `flea_category` VALUES (2, '电子产品', 'http://localhost:10001/img/icon-2.png', 2, '2021-04-07 19:35:03');
INSERT INTO `flea_category` VALUES (3, '其他', 'http://localhost:10001/img/icon-3.png', 3, '2021-04-08 19:35:23');

-- ----------------------------
-- Table structure for flea_goods
-- ----------------------------
DROP TABLE IF EXISTS `flea_goods`;
CREATE TABLE `flea_goods`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '物品名称',
  `category_id` int(11) NULL DEFAULT NULL COMMENT '分类ID',
  `price` decimal(10, 2) NULL DEFAULT NULL COMMENT '价格',
  `pic_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图片',
  `status` tinyint(2) NULL DEFAULT NULL COMMENT '上下架',
  `describe` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '描述',
  `member_id` int(11) NULL DEFAULT NULL COMMENT '会员ID',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 25 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '商品' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of flea_goods
-- ----------------------------
INSERT INTO `flea_goods` VALUES (18, '冰红茶', 3, 3.00, 'http://localhost:10001/fileupload/20210414/0d8c6538-151c-4a34-b2c8-b00d73ae488e.jpg', 2, '冰镇滴', 69, '2021-04-14 14:17:15');
INSERT INTO `flea_goods` VALUES (19, '罪与罚', 1, 50.00, 'http://localhost:10001/fileupload/20210415/48d260af-0941-458f-8132-6c91460f2cea.jpg', 2, '《罪与罚》是俄国作家陀思妥耶夫斯基创作的长篇小说，也是其代表作', 69, '2021-04-15 14:03:28');
INSERT INTO `flea_goods` VALUES (20, '忻州往事', 1, 50.00, 'http://localhost:10001/fileupload/20210415/9e7e9702-7de1-4c0a-a143-6890ef048fc6.jpg', 2, 'IMBD，豆瓣排名TOP250佳作', 69, '2021-04-15 14:11:38');
INSERT INTO `flea_goods` VALUES (21, '德彪西-月光奏鸣曲', 3, 150.00, 'http://localhost:10001/fileupload/20210415/8a9033c1-bf2e-40a4-9b47-fbb2ed71ab24.jpg', 2, '《月光曲》是阿希尔-克洛德·德彪西的作品。《月光》隶属于《贝加摩组曲》，作于1900年，是阿希尔-克洛德·德彪西第一期作品', 69, '2021-04-15 14:22:43');
INSERT INTO `flea_goods` VALUES (23, '希望之线', 1, 50.00, 'http://localhost:10001/fileupload/20210511/6a30e8e5-c7a2-4c5e-8b6c-83645e518b86.jpg', 1, '快来买吧', 69, '2021-05-11 01:12:27');
INSERT INTO `flea_goods` VALUES (24, '希望之线', 1, 50.00, 'http://localhost:10001/fileupload/20210511/6a30e8e5-c7a2-4c5e-8b6c-83645e518b86.jpg', 1, '快来买吧', 69, '2021-05-11 01:11:51');
INSERT INTO `flea_goods` VALUES (25, '红与黑', 1, 50.00, 'http://localhost:10001/fileupload/20210527/7d666885-9af5-422a-a8ac-2bd519b97f2b.jpg', 2, '司汤达（1783~1842）。原名马里-亨利·贝尔（Marie-HenriBeyle），“司汤达”（又译斯丹达尔）是他的笔名，19世纪法国批判现实主义作家。代表著作为《阿尔芒斯》、《红与黑》（1830年）', 69, '2021-05-27 08:59:14');

-- ----------------------------
-- Table structure for flea_goods_pic
-- ----------------------------
DROP TABLE IF EXISTS `flea_goods_pic`;
CREATE TABLE `flea_goods_pic`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NULL DEFAULT NULL COMMENT '商品ID',
  `pic_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图片',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '商品图片' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of flea_goods_pic
-- ----------------------------
INSERT INTO `flea_goods_pic` VALUES (1, 2, 'http://localhost:10001/img/goods-1.jpg');
INSERT INTO `flea_goods_pic` VALUES (2, 3, 'http://localhost:10001/img/goods-2.jpg');
INSERT INTO `flea_goods_pic` VALUES (3, 4, 'http://localhost:10001/img/goods-3.jpg');
INSERT INTO `flea_goods_pic` VALUES (4, 5, 'http://localhost:10001/img/goods-3.jpg');
INSERT INTO `flea_goods_pic` VALUES (5, 6, 'http://localhost:10001/img/goods-3.jpg');
INSERT INTO `flea_goods_pic` VALUES (6, 7, 'http://localhost:10001/img/goods-3.jpg');
INSERT INTO `flea_goods_pic` VALUES (7, 8, 'http://localhost:10001/img/goods-3.jpg');
INSERT INTO `flea_goods_pic` VALUES (13, 16, 'http://localhost:10001/fileupload/20210331/e893c18f-472d-4933-8ab6-783b800f1c67.png');
INSERT INTO `flea_goods_pic` VALUES (14, 17, 'http://localhost:10001/fileupload/20210414/00444892-0ede-4b0e-a118-4b0baae96817.png');
INSERT INTO `flea_goods_pic` VALUES (15, 18, 'http://localhost:10001/fileupload/20210414/0d8c6538-151c-4a34-b2c8-b00d73ae488e.jpg');
INSERT INTO `flea_goods_pic` VALUES (16, 19, 'http://localhost:10001/fileupload/20210415/48d260af-0941-458f-8132-6c91460f2cea.jpg');
INSERT INTO `flea_goods_pic` VALUES (17, 20, 'http://localhost:10001/fileupload/20210415/9e7e9702-7de1-4c0a-a143-6890ef048fc6.jpg');
INSERT INTO `flea_goods_pic` VALUES (18, 21, 'http://localhost:10001/fileupload/20210415/8a9033c1-bf2e-40a4-9b47-fbb2ed71ab24.jpg');
INSERT INTO `flea_goods_pic` VALUES (19, 22, 'http://localhost:10001/fileupload/20210415/09eb9c99-803b-4b3a-9d48-56a51fc1a23d.webp');
INSERT INTO `flea_goods_pic` VALUES (20, 23, 'http://localhost:10001/fileupload/20210511/6a30e8e5-c7a2-4c5e-8b6c-83645e518b86.jpg');
INSERT INTO `flea_goods_pic` VALUES (21, 24, 'http://localhost:10001/fileupload/20210511/6a30e8e5-c7a2-4c5e-8b6c-83645e518b86.jpg');
INSERT INTO `flea_goods_pic` VALUES (22, 25, 'http://localhost:10001/fileupload/20210527/7d666885-9af5-422a-a8ac-2bd519b97f2b.jpg');

-- ----------------------------
-- Table structure for flea_member
-- ----------------------------
DROP TABLE IF EXISTS `flea_member`;
CREATE TABLE `flea_member`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `openid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '微信openid',
  `nickname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '昵称',
  `avatar_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '头像',
  `gender` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '性别',
  `real_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '姓名',
  `mobile` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号码',
  `login_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '登录账号',
  `password` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '密码',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 70 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '会员' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of flea_member
-- ----------------------------
INSERT INTO `flea_member` VALUES (69, 'oEy946NX-PE_EF8dKJYuHX3z9oDw', 'Cyh', 'http://localhost:10001/fileupload/20210414/ee449e73-aeac-4763-8387-9addd732c4d6.jpg', '1', 'Cyh', '18222221427', NULL, NULL, '2021-04-14 10:55:34');

-- ----------------------------
-- Table structure for flea_member_address
-- ----------------------------
DROP TABLE IF EXISTS `flea_member_address`;
CREATE TABLE `flea_member_address`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NULL DEFAULT NULL COMMENT '会员id',
  `contacts` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '联系人',
  `mobile` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机',
  `province_id` int(11) NULL DEFAULT NULL COMMENT '省',
  `province_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `city_id` int(11) NULL DEFAULT NULL COMMENT '市',
  `city_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `district_id` int(11) NULL DEFAULT NULL COMMENT '区',
  `district_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '详细地址',
  `zipcode` int(11) NULL DEFAULT NULL COMMENT '邮编',
  `dft` tinyint(1) NULL DEFAULT NULL COMMENT '默认地址',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户地址' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of flea_member_address
-- ----------------------------
INSERT INTO `flea_member_address` VALUES (9, 66, '微服汇', '18112907714', NULL, '北京市', NULL, '北京市', NULL, '东城区', '测试', NULL, 1, '2021-04-08 23:44:27');
INSERT INTO `flea_member_address` VALUES (10, 69, '蔡元昊', '18222221427', NULL, '天津市', NULL, '天津市', NULL, '西青区', '天津工业大学', NULL, 1, '2021-04-14 11:03:13');

-- ----------------------------
-- Table structure for flea_order
-- ----------------------------
DROP TABLE IF EXISTS `flea_order`;
CREATE TABLE `flea_order`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NULL DEFAULT NULL COMMENT '用户ID',
  `order_number` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '订单编号',
  `total_amount` decimal(10, 2) NULL DEFAULT NULL COMMENT '订单金额',
  `order_status` tinyint(3) NULL DEFAULT NULL COMMENT '订单状态，0：已取消，1：待付款，2：已完成',
  `courier_num` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '物流单号',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 33 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '订单' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of flea_order
-- ----------------------------
INSERT INTO `flea_order` VALUES (26, 69, '20210414662189', 3.00, 1, NULL, '', '2021-04-14 14:39:39');
INSERT INTO `flea_order` VALUES (27, 69, '20210414877445', 3.00, 2, NULL, '', '2021-04-14 14:42:14');
INSERT INTO `flea_order` VALUES (28, 69, '20210414732235', 3.00, 2, NULL, '别放辣子', '2021-04-14 23:12:54');
INSERT INTO `flea_order` VALUES (29, 69, '20210415647409', 150.00, 2, NULL, '', '2021-04-15 14:32:35');
INSERT INTO `flea_order` VALUES (30, 69, '20210415454006', 150.00, 2, NULL, '', '2021-04-15 15:12:57');
INSERT INTO `flea_order` VALUES (31, 69, '20210511625243', 150.00, 1, NULL, '', '2021-05-11 00:45:09');
INSERT INTO `flea_order` VALUES (32, 69, '20210511579063', 150.00, 2, NULL, '', '2021-05-11 00:45:56');

-- ----------------------------
-- Table structure for flea_order_evaluation
-- ----------------------------
DROP TABLE IF EXISTS `flea_order_evaluation`;
CREATE TABLE `flea_order_evaluation`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `order_id` int(11) NULL DEFAULT NULL COMMENT '订单id',
  `member_id` int(11) NULL DEFAULT NULL COMMENT '用户id',
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '评价内容',
  `star` int(11) NULL DEFAULT NULL,
  `goods_id` int(11) NULL DEFAULT NULL COMMENT '商品id',
  `create_time` datetime NULL DEFAULT NULL COMMENT '评价时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '订单评价' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of flea_order_evaluation
-- ----------------------------
INSERT INTO `flea_order_evaluation` VALUES (2, NULL, 66, '123', NULL, 2, '2021-02-10 19:34:00');
INSERT INTO `flea_order_evaluation` VALUES (3, NULL, 66, '这个是不是全新的呀', NULL, 2, '2021-03-12 00:10:12');
INSERT INTO `flea_order_evaluation` VALUES (4, NULL, 69, '能再便宜些吗', NULL, 21, '2021-04-15 14:32:21');
INSERT INTO `flea_order_evaluation` VALUES (5, NULL, 69, '扎不多德勒', NULL, 20, '2021-04-15 14:33:17');
INSERT INTO `flea_order_evaluation` VALUES (6, NULL, 69, '成分里有水吗', NULL, 18, '2021-04-15 14:33:37');
INSERT INTO `flea_order_evaluation` VALUES (7, NULL, 69, '瑞思拜\n', NULL, 20, '2021-04-15 14:41:05');
INSERT INTO `flea_order_evaluation` VALUES (8, NULL, 69, '请问能不能便宜一些', NULL, 18, '2021-05-27 08:57:20');

-- ----------------------------
-- Table structure for flea_order_goods
-- ----------------------------
DROP TABLE IF EXISTS `flea_order_goods`;
CREATE TABLE `flea_order_goods`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NULL DEFAULT NULL COMMENT '订单ID',
  `goods_id` int(11) NULL DEFAULT NULL COMMENT '商品ID',
  `goods_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品名称',
  `num` int(11) NULL DEFAULT NULL COMMENT '数量',
  `pic_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品图片',
  `price` decimal(10, 2) NULL DEFAULT NULL COMMENT '价格',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 33 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '订单详情' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of flea_order_goods
-- ----------------------------
INSERT INTO `flea_order_goods` VALUES (12, 12, 7, 'android代做', 1, 'http://localhost:10001/img/goods-5.jpg', 300.00);
INSERT INTO `flea_order_goods` VALUES (13, 13, 8, 'springcloud代做', 1, 'http://localhost:10001/img/goods-3.jpg', 500.00);
INSERT INTO `flea_order_goods` VALUES (14, 14, 8, 'springcloud代做', 1, 'http://localhost:10001/img/goods-3.jpg', 500.00);
INSERT INTO `flea_order_goods` VALUES (15, 15, 8, 'springcloud代做', 1, 'http://localhost:10001/img/goods-3.jpg', 500.00);
INSERT INTO `flea_order_goods` VALUES (16, 16, 8, 'springcloud代做', 1, 'http://localhost:10001/img/goods-3.jpg', 500.00);
INSERT INTO `flea_order_goods` VALUES (17, 17, 7, '家常小炒', 1, 'http://localhost:10001/img/goods-5.jpg', 30.00);
INSERT INTO `flea_order_goods` VALUES (18, 17, 4, '超值炸鸡', 1, 'http://localhost:10001/img/goods-3.jpg', 10.00);
INSERT INTO `flea_order_goods` VALUES (19, 19, 5, 'springboot代做', 1, 'http://localhost:10001/img/goods-4.jpg', 200.00);
INSERT INTO `flea_order_goods` VALUES (21, 21, 7, 'android代做', 1, 'http://localhost:10001/img/goods-5.jpg', 300.00);
INSERT INTO `flea_order_goods` VALUES (22, 22, 7, 'android代做', 1, 'http://localhost:10001/img/goods-5.jpg', 300.00);
INSERT INTO `flea_order_goods` VALUES (23, 23, 7, 'android代做', 1, 'http://localhost:10001/img/goods-5.jpg', 300.00);
INSERT INTO `flea_order_goods` VALUES (24, 24, 8, 'springcloud编程', 1, 'http://localhost:10001/img/goods-3.jpg', 500.00);
INSERT INTO `flea_order_goods` VALUES (25, 25, 8, 'springcloud编程', 1, 'http://localhost:10001/img/goods-3.jpg', 500.00);
INSERT INTO `flea_order_goods` VALUES (26, 26, 18, '冰红茶', 1, 'http://localhost:10001/fileupload/20210414/0d8c6538-151c-4a34-b2c8-b00d73ae488e.jpg', 3.00);
INSERT INTO `flea_order_goods` VALUES (27, 27, 18, '冰红茶', 1, 'http://localhost:10001/fileupload/20210414/0d8c6538-151c-4a34-b2c8-b00d73ae488e.jpg', 3.00);
INSERT INTO `flea_order_goods` VALUES (28, 28, 18, '冰红茶', 1, 'http://localhost:10001/fileupload/20210414/0d8c6538-151c-4a34-b2c8-b00d73ae488e.jpg', 3.00);
INSERT INTO `flea_order_goods` VALUES (29, 29, 21, '德彪西-月光奏鸣曲', 1, 'http://localhost:10001/fileupload/20210415/8a9033c1-bf2e-40a4-9b47-fbb2ed71ab24.jpg', 150.00);
INSERT INTO `flea_order_goods` VALUES (30, 30, 21, '德彪西-月光奏鸣曲', 1, 'http://localhost:10001/fileupload/20210415/8a9033c1-bf2e-40a4-9b47-fbb2ed71ab24.jpg', 150.00);
INSERT INTO `flea_order_goods` VALUES (31, 31, 21, '德彪西-月光奏鸣曲', 1, 'http://localhost:10001/fileupload/20210415/8a9033c1-bf2e-40a4-9b47-fbb2ed71ab24.jpg', 150.00);
INSERT INTO `flea_order_goods` VALUES (32, 32, 21, '德彪西-月光奏鸣曲', 1, 'http://localhost:10001/fileupload/20210415/8a9033c1-bf2e-40a4-9b47-fbb2ed71ab24.jpg', 150.00);

-- ----------------------------
-- Table structure for flea_order_shipment
-- ----------------------------
DROP TABLE IF EXISTS `flea_order_shipment`;
CREATE TABLE `flea_order_shipment`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `order_id` int(11) NULL DEFAULT NULL COMMENT '订单ID',
  `contacts` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '联系人',
  `mobile` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号码',
  `province_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '省名称',
  `city_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '城市名称',
  `district_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '地区名称',
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '详细地址',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '订单配送' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of flea_order_shipment
-- ----------------------------
INSERT INTO `flea_order_shipment` VALUES (1, 21, NULL, '189111111111', NULL, NULL, NULL, '测试', NULL);
INSERT INTO `flea_order_shipment` VALUES (2, 22, NULL, '18888888888', NULL, NULL, NULL, '测试', NULL);
INSERT INTO `flea_order_shipment` VALUES (3, 23, NULL, '18911111111', NULL, NULL, NULL, '测试', NULL);
INSERT INTO `flea_order_shipment` VALUES (4, 24, NULL, '18888888888', NULL, NULL, NULL, '测试', NULL);
INSERT INTO `flea_order_shipment` VALUES (5, 25, NULL, '18111111111', NULL, NULL, NULL, '测试', NULL);
INSERT INTO `flea_order_shipment` VALUES (6, 28, '蔡元昊', '18222221427', '天津市', '天津市', '西青区', '天津工业大学', NULL);
INSERT INTO `flea_order_shipment` VALUES (7, 30, '蔡元昊', '18222221427', '天津市', '天津市', '西青区', '天津工业大学', NULL);

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户名',
  `password` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '密码',
  `salt` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '盐',
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `mobile` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号',
  `status` tinyint(4) NULL DEFAULT NULL COMMENT '状态  0：禁用   1：正常',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '管理员' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, 'admin', '9ec9750e709431dad22365cabc5c625482e574c74adaebba7dd02f1129e4ce1d', 'YzcmCZNvbXocrsz9dm8e', '2803180149@qq.com', '18021418906', 1, '2021-04-05 11:11:11');

SET FOREIGN_KEY_CHECKS = 1;
